import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {UsuariosComponent} from './usuarios.component';
import {DetailsUserComponent} from './details-user/details-user.component';

const routes: Routes = [
  {
    path: '',
    component: UsuariosComponent
  },
  {
    path: '*',
    component: UsuariosComponent
  },
  {
    path: '/:user',
    component: DetailsUserComponent
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class UsuariosRouting { }

//import { RouterModule, Routes } from '@angular/router';
//
// // Micro-app BOC
// import {SolicitudAaffGuardService} from '../../services/guards/solicitud-aaff-guard.service';
// import {SolicitudPymesGuardService} from '../../services/guards/solicitud-pymes-guard.service';
// import {SolicitudGgccGuardService} from '../../services/guards/solicitud-ggcc-guard.service';
// import {CorporativosComponent} from './corporativos.component';
// import {DocumentacionCorporativosComponent} from './pages/documentacion/documentacion-corporativos.component';
// import {SolicitudesCorporativosComponent} from './pages/solicitudes/solicitudes-corporativos.component';
// import {CuadroMandoCorporativosComponent} from './pages/cuadro-mando/cuadro-mando-corporativos.component';
// import {FacturacionComponent} from '../../shared/facturacion/facturacion.component';
// import {FacturacionGuardService} from '../../services/guards/facturacion-guard.service';
// import {PrefacturaComponent} from '../../shared/facturacion/prefactura/prefactura.component';
// import {SolicitudAaffComponent} from '../../shared/solicitud-aaff/solicitud-aaff.component';
// import {SolicitudPymesComponent} from '../../shared/solicitud-pymes/solicitud-pymes.component';
// import {SolicitudWizzardGgccComponent} from '../../shared/solicitud-wizzard-ggcc/solicitud-wizzard-ggcc.component';
//
//
//
// const corporativosRoutes: Routes = [
//   {
//     path: '',
//     component: CorporativosComponent,
//     children: [
//       {path: 'solicitudes', component: SolicitudesCorporativosComponent},
//       { path: 'aaff/solicitud/:id', component: SolicitudAaffComponent, canDeactivate: [SolicitudAaffGuardService] },
//       { path: 'pymes/solicitud/:id', component: SolicitudPymesComponent , canDeactivate: [SolicitudPymesGuardService]},
//       { path: 'ggcc/solicitud/:id', component: SolicitudWizzardGgccComponent , canDeactivate: [SolicitudGgccGuardService]},
//       {path: '', pathMatch: 'full', redirectTo: 'solicitudes'},
//       {path: 'help', component: DocumentacionCorporativosComponent},
//       {path: 'dashboard', component: CuadroMandoCorporativosComponent},
//       {path: ':sector/facturacion', component: FacturacionComponent, canActivate:[FacturacionGuardService]},
//       {path: ':sector/facturacion/prefactura/:mes/:anio', component: PrefacturaComponent, canActivate: [FacturacionGuardService]},
//     ]
//   },
// ];
//
// export const CORPORATIVOS_ROUTES =  RouterModule.forChild(corporativosRoutes);
